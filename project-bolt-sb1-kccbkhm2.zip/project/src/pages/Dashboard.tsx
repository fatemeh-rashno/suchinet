import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import Overview from './dashboard/Overview';
import Profile from './dashboard/Profile';
import Cart from './Cart';
import { useAuth } from '../contexts/AuthContext';

export default function Dashboard() {
  const { user } = useAuth();

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <Routes>
        <Route index element={<Overview />} />
        <Route path="profile" element={<Profile />} />
        <Route path="cart" element={<Cart />} />
      </Routes>
    </div>
  );
}