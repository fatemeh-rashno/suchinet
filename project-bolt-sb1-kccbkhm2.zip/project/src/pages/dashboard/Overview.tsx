import React from 'react';
import { Link } from 'react-router-dom';
import { ShoppingCart, MapPin, User } from 'lucide-react';

export default function Overview() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <Link
        to="/dashboard/cart"
        className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow"
      >
        <div className="flex items-center gap-4">
          <div className="p-3 bg-blue-100 rounded-full">
            <ShoppingCart className="w-6 h-6 text-blue-600" />
          </div>
          <div>
            <h3 className="font-semibold text-lg">سبد خرید</h3>
            <p className="text-sm text-gray-600">مشاهده و مدیریت سبد خرید</p>
          </div>
        </div>
      </Link>

      <Link
        to="/dashboard/addresses"
        className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow"
      >
        <div className="flex items-center gap-4">
          <div className="p-3 bg-green-100 rounded-full">
            <MapPin className="w-6 h-6 text-green-600" />
          </div>
          <div>
            <h3 className="font-semibold text-lg">آدرس‌ها</h3>
            <p className="text-sm text-gray-600">مدیریت آدرس‌های ارسال</p>
          </div>
        </div>
      </Link>

      <Link
        to="/dashboard/profile"
        className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow"
      >
        <div className="flex items-center gap-4">
          <div className="p-3 bg-purple-100 rounded-full">
            <User className="w-6 h-6 text-purple-600" />
          </div>
          <div>
            <h3 className="font-semibold text-lg">حساب کاربری</h3>
            <p className="text-sm text-gray-600">مدیریت اطلاعات حساب</p>
          </div>
        </div>
      </Link>
    </div>
  );
}