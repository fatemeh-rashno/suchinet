import React from 'react';
import { useParams } from 'react-router-dom';

export default function ProductDetail() {
  const { id } = useParams();

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-6">جزئیات محصول</h1>
      <div className="bg-white p-6 rounded-lg shadow-md">
        <p className="text-gray-600">محصول شماره: {id}</p>
      </div>
    </div>
  );
}