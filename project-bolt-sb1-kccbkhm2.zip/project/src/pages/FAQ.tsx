import React from 'react';

export default function FAQ() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-6">سوالات متداول</h1>
      <div className="bg-white p-6 rounded-lg shadow-md">
        <p className="text-gray-600">سوالات متداول به زودی اضافه خواهند شد...</p>
      </div>
    </div>
  );
}