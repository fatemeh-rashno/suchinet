import React from 'react';

export default function Products() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-6">محصولات</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {/* Placeholder content */}
        <div className="bg-white p-4 rounded-lg shadow-md">
          <p className="text-gray-600">محصولات به زودی اضافه خواهند شد...</p>
        </div>
      </div>
    </div>
  );
}