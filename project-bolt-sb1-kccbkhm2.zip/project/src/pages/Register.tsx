import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { validatePassword } from '../utils/validation';
import { AuthError } from '../types/auth';
import { useAuth } from '../contexts/AuthContext';

export default function Register() {
  const navigate = useNavigate();
  const { register } = useAuth();
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: '',
  });
  const [errors, setErrors] = useState<AuthError[]>([]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const newErrors: AuthError[] = [];
    
    if (!formData.username) {
      newErrors.push({ field: 'username', message: 'نام کاربری الزامی است' });
    }
    
    if (!formData.email || !/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.push({ field: 'email', message: 'ایمیل معتبر نیست' });
    }
    
    const passwordErrors = validatePassword(formData.password);
    passwordErrors.forEach(error => {
      newErrors.push({ field: 'password', message: error });
    });

    if (newErrors.length > 0) {
      setErrors(newErrors);
      return;
    }

    try {
      await register(formData.username, formData.email, formData.password);
      navigate('/dashboard');
    } catch (error) {
      if (error instanceof Error) {
        setErrors([{ field: 'submit', message: error.message }]);
      } else {
        setErrors([{ field: 'submit', message: 'خطا در ثبت‌نام. لطفاً دوباره تلاش کنید.' }]);
      }
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-md mx-auto bg-white p-8 rounded-lg shadow-md">
        <h1 className="text-2xl font-bold mb-6">ثبت نام</h1>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">نام کاربری</label>
            <input
              type="text"
              name="username"
              value={formData.username}
              onChange={handleChange}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-200"
            />
            {errors.find(e => e.field === 'username') && (
              <p className="mt-1 text-sm text-red-600">{errors.find(e => e.field === 'username')?.message}</p>
            )}
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700">ایمیل</label>
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-200"
            />
            {errors.find(e => e.field === 'email') && (
              <p className="mt-1 text-sm text-red-600">{errors.find(e => e.field === 'email')?.message}</p>
            )}
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700">رمز عبور</label>
            <input
              type="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-200"
            />
            {errors.filter(e => e.field === 'password').map((error, index) => (
              <p key={index} className="mt-1 text-sm text-red-600">{error.message}</p>
            ))}
          </div>

          {errors.find(e => e.field === 'submit') && (
            <div className="bg-red-50 p-4 rounded-md">
              <p className="text-sm text-red-600">{errors.find(e => e.field === 'submit')?.message}</p>
            </div>
          )}
          
          <button
            type="submit"
            className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700"
          >
            ثبت نام
          </button>
        </form>
        
        <p className="mt-4 text-center text-sm text-gray-600">
          قبلاً ثبت نام کرده‌اید؟{' '}
          <Link to="/login" className="text-blue-600 hover:text-blue-700">
            وارد شوید
          </Link>
        </p>
      </div>
    </div>
  );
}