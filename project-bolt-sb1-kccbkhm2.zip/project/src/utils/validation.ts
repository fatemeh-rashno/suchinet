export const validatePassword = (password: string): string[] => {
  const errors: string[] = [];
  
  if (password.length < 5) {
    errors.push('رمز عبور باید حداقل 5 کاراکتر باشد');
  }
  
  if (!/[A-Z]/.test(password)) {
    errors.push('رمز عبور باید حداقل یک حرف بزرگ داشته باشد');
  }
  
  if (!/\d/.test(password)) {
    errors.push('رمز عبور باید حداقل یک عدد داشته باشد');
  }
  
  return errors;
};