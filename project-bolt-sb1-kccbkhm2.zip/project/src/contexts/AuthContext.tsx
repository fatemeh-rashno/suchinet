import React, { createContext, useContext, useState } from 'react';
import { User } from '../types/auth';

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<void>;
  register: (username: string, email: string, password: string) => Promise<void>;
  logout: () => void;
  updatePassword: (newPassword: string) => Promise<void>;
  updateProfile: (data: { avatar?: File }) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Simulated user database
const USERS: User[] = [];

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);

  const login = async (email: string, password: string) => {
    const foundUser = USERS.find(u => u.email === email);
    if (!foundUser) {
      throw new Error('کاربری با این ایمیل یافت نشد');
    }
    setUser(foundUser);
  };

  const register = async (username: string, email: string, password: string) => {
    if (USERS.some(u => u.email === email)) {
      throw new Error('این ایمیل قبلاً ثبت شده است');
    }
    if (USERS.some(u => u.username === username)) {
      throw new Error('این نام کاربری قبلاً ثبت شده است');
    }

    const newUser: User = {
      id: Date.now().toString(),
      username,
      email,
      createdAt: new Date().toISOString()
    };
    
    USERS.push(newUser);
    setUser(newUser);
  };

  const updatePassword = async (newPassword: string) => {
    if (!user) throw new Error('کاربر وارد نشده است');
    // در حالت واقعی، اینجا رمز عبور در دیتابیس آپدیت می‌شود
  };

  const updateProfile = async (data: { avatar?: File }) => {
    if (!user) throw new Error('کاربر وارد نشده است');
    if (data.avatar) {
      // در حالت واقعی، اینجا تصویر آپلود می‌شود
      const avatarUrl = URL.createObjectURL(data.avatar);
      setUser({ ...user, avatar: avatarUrl });
    }
  };

  const logout = () => {
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ 
      user, 
      login, 
      register, 
      logout,
      updatePassword,
      updateProfile 
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}