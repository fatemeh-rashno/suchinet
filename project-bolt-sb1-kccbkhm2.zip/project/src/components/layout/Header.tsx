import React from 'react';
import { Link } from 'react-router-dom';
import { ShoppingCart, User, Search, LogOut } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

export default function Header() {
  const { user, logout } = useAuth();

  return (
    <header className="bg-white shadow-md">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <Link to="/" className="text-2xl font-bold text-gray-800">فروشگاه</Link>
          
          <div className="flex items-center gap-6">
            <div className="relative">
              <input
                type="text"
                placeholder="جستجو..."
                className="w-64 px-4 py-2 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
            </div>
            
            <nav className="hidden md:flex items-center gap-6">
              <Link to="/products" className="text-gray-600 hover:text-gray-900">محصولات</Link>
              <Link to="/faq" className="text-gray-600 hover:text-gray-900">سوالات متداول</Link>
              <Link to="/contact" className="text-gray-600 hover:text-gray-900">تماس با ما</Link>
            </nav>
            
            <div className="flex items-center gap-4">
              <Link to="/cart" className="relative">
                <ShoppingCart className="h-6 w-6 text-gray-600" />
                <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                  0
                </span>
              </Link>

              <div className="relative group">
                <button className="flex items-center">
                  <User className="h-6 w-6 text-gray-600" />
                </button>

                <div className="absolute left-0 mt-2 w-48 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 focus:outline-none transform opacity-0 scale-95 group-hover:opacity-100 group-hover:scale-100 transition-all duration-200">
                  {user ? (
                    <div className="py-1">
                      <Link to="/dashboard/orders" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                        سفارش‌ها
                      </Link>
                      <Link to="/dashboard" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                        پیشخوان
                      </Link>
                      <Link to="/dashboard/addresses" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                        آدرس‌ها
                      </Link>
                      <button
                        onClick={() => logout()}
                        className="w-full text-right px-4 py-2 text-sm text-red-600 hover:bg-gray-100 flex items-center gap-2"
                      >
                        <LogOut className="h-4 w-4" />
                        خروج
                      </button>
                    </div>
                  ) : (
                    <div className="py-1">
                      <Link to="/login" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                        ورود
                      </Link>
                      <Link to="/register" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                        ثبت نام
                      </Link>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}