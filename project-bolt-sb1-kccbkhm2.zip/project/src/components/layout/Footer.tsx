import React from 'react';
import { Link } from 'react-router-dom';
import { Phone, Mail, MapPin } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-gray-800 text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-4">دسترسی سریع</h3>
            <ul className="space-y-2">
              <li><Link to="/products">محصولات</Link></li>
              <li><Link to="/returns">بازگرداندن کالا</Link></li>
              <li><Link to="/faq">سوالات متداول</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-xl font-bold mb-4">خدمات مشتریان</h3>
            <ul className="space-y-2">
              <li><Link to="/contact">تماس با ما</Link></li>
              <li><Link to="/about">درباره ما</Link></li>
              <li><Link to="/returns">شرایط بازگشت کالا</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-xl font-bold mb-4">اطلاعات تماس</h3>
            <ul className="space-y-4">
              <li className="flex items-center gap-2">
                <Phone className="h-5 w-5" />
                <span>۰۲۱-########</span>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="h-5 w-5" />
                <span>info@example.com</span>
              </li>
              <li className="flex items-center gap-2">
                <MapPin className="h-5 w-5" />
                <span>تهران، خیابان ...</span>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-xl font-bold mb-4">درباره ما</h3>
            <p className="text-gray-300 leading-relaxed">
              ما متعهد به ارائه بهترین محصولات با کیفیت عالی به مشتریان خود هستیم.
            </p>
          </div>
        </div>
        
        <div className="border-t border-gray-700 mt-8 pt-8 text-center">
          <p>© {new Date().getFullYear()} تمامی حقوق محفوظ است.</p>
        </div>
      </div>
    </footer>
  );
}