export interface AuthError {
  field: string;
  message: string;
}

export interface User {
  id: string;
  username: string;
  email: string;
  createdAt: string;
  avatar?: string;
}

export interface UserProfile extends User {
  addresses: Address[];
  orders: Order[];
}

export interface Address {
  id: string;
  title: string;
  fullAddress: string;
  postalCode: string;
  phone: string;
}

export interface Order {
  id: string;
  date: string;
  status: 'pending' | 'processing' | 'shipped' | 'delivered';
  total: number;
}